import './App.css';
import {createElement, useState} from "react";
import AddDiv from "./components/action/AddDiv";
import PictureSize from "./components/action/pictureSize/PictureSize";
import Brush from "./components/action/Brush";
import Eraser from "./components/action/Eraser";
import Svg from "./components/action/Svg";
import Input from "./components/action/Input";
import Folder from "./components/action/Folder";
import Content from "./components/action/content/Content";
import PictureInput from "./components/action/pictureSize/PictureInput";
import BorderNone from "./components/action/footerAction/BorderNone";
import SavePicture from "./components/action/footerAction/SavePicture";
import SaveFolder from "./components/action/footerAction/SaveFolder";

function App() {
    const [arrayContent, setArrayContent] = useState([{
        r: 155, g: 175, b: 200
    }])
    const [color, setColor] = useState({
        r: 0, g: 0, b: 0
    })

    const [eraser, setEraser] = useState(false)
    const [brush, setBrush] = useState(false)
    const [inp, setInp] = useState(false)
    const [column, setColumn] = useState(1)
    const [checkbox, setCheckbox] = useState(false)
    const [selectFolder, setSelectFolder] = useState([])
    const [folder, setFolder] = useState(false)
    const [picture, setPicture] = useState(false)
    let row = document.querySelector('.row')
    let folderInp = document.querySelector('.folderInp')

    function update(newArrayContent) {
        setArrayContent([...arrayContent, newArrayContent])
    }

    function clean() {
        alert(!eraser)
        setBrush(false)
        setEraser(!eraser)
    }

    function save() {
        setPicture(!picture)
    }

    function pickFile(value,index) {
        console.log(value)
        setArrayContent(value.arrayContent)
        folderFunc()
        setColumn(selectFolder[index].column)

    }

    function save2() {
        let folderInp = document.querySelector('.folderInp')
        console.log(folderInp.value)
        if (folderInp.value === '') {
            alert('Please enter the name of folder')
        } else {
            setSelectFolder([...selectFolder, {
                folderInp:folderInp.value,
                arrayContent:arrayContent,
                column:column
            }])
        }
        // selectFolder.column
        save()
    }


    function change() {
        alert(!brush)
        setEraser(false)
        setBrush(!brush)
    }

    function draw() {
        setArrayContent([])
        setInp(!inp)
    }

    function check() {
        setCheckbox(!checkbox)
        console.log(!checkbox)
    }

    function generate(columnInput) {
        row = document.querySelector('.row')
        console.log(columnInput.value)
        console.log(+columnInput.value * +row.value)
        if (row.value > 75 || columnInput.value > 75 || row.value < 1 || columnInput.value < 1) {
            alert('Could not generate the box you can write less than 75 and above 0')
        } else if (!columnInput.value || !row.value) {
            alert('you must write a number in each box')
        } else {
            {
                for (let i = 0; i < +columnInput.value * +row.value; i++) {
                    arrayContent.push({
                        r: 255, g: 255, b: 255
                    })
                }
                console.log(row.value, 'b')
                setArrayContent([...arrayContent])
                setColumn(columnInput.value)
                setInp(!inp)
            }
        }
    }

    function folderFunc() {
        console.log(color)
        setColor(color)
        setFolder(!folder)
    }
    function colorRender(e){
        console.log(e)
        const hexToRgb = hex => hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, (m, r, g, b) => '#' + r + r + g + g + b + b)
            .substring(1).match(/.{2}/g)
            .map(x => parseInt(x, 16))

        let newColor = hexToRgb(e.value)
        setColor({
            r: newColor[0], g: newColor[1], b: newColor[2]
        })
    }
    function startAllAction() {
        if (!inp && !picture && !folder) {
            console.log('a')
            return (
                <div className="App">
                    <div className="app_div">
                        <AddDiv update={update}/>
                        <PictureSize draw={draw}/>
                        <Brush change={change}/>
                        <Eraser clean={clean}/>
                        <Svg update={update} color={color}/>
                        <Input setColor={setColor} colorRender={colorRender} color={color}/>
                        <Folder folderFunc={folderFunc}/>
                    </div>
                    {mainContent()}
                    <div className="div8">
                        <BorderNone checkbox={checkbox}
                                    check={check}/>
                        <SavePicture save={save}/>
                    </div>
                </div>
            )
        } else if (!inp && picture &&!folder) {
            console.log('hello')
            return (
                <SaveFolder save2={save2}/>
            )
        } else if (inp) {
            return (
                <div className="App">
                    <PictureSize draw={draw}/>
                    <PictureInput
                        column={column}
                        setColumn={setColumn}
                        generate={generate}/>
                </div>
            )
        } else if (folder) {
            return (
                <div className="App">
                    <Folder folderFunc={folderFunc}/>
                    {selectFolder.map((value,index)=>{
                        return(
                            <p onClick={()=>{
                                pickFile(value,index)
                            }} key={index}>{value.folderInp}</p>
                        )
                    })}
                </div>
            )
        } else {
            return ''
        }
    }


    function mainContent() {
        if (setArrayContent && arrayContent) {
            return (
                <Content setArrayContent={setArrayContent}
                         arrayContent={arrayContent}
                         color={color}
                         brush={brush}
                         eraser={eraser}
                         checkbox={checkbox}
                         column={column}
                />
            )
        }
    }

    function checkboxInp() {

    }

    function btnFolder() {
        return (
            <div className="div9">
                <input type="text" name="" id="" placeholder={'Name of folder'}/>
                <button className="btn2"
                        onClick={save2}>Save picture2
                </button>
            </div>
        )
    }


    return (
        <div className="App">
            {startAllAction()}


        </div>);
}

export default App;
