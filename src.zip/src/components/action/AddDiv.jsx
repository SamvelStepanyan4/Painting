export default function AddDiv({update}) {
    return (
        <button className="btn1"
                onClick={() => {
                    update({
                        r: Math.floor(Math.random() * 255),
                        g: Math.floor(Math.random() * 255),
                        b: Math.floor(Math.random() * 255)
                    })
                }}>+
        </button>
    )
}