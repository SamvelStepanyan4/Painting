export default function BorderNone({check, checkbox}){
    return (
        <div className="check">
            <input type="checkbox" name="" id="" checked={checkbox} onChange={() => {
                check()
            }}/>
            <b><p className="check_p">remove borders</p></b>
        </div>
    )
}