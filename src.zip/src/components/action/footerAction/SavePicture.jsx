export default function SavePicture({save}) {
    return (
        <button className="btn2"
                onClick={save}>Save picture
        </button>
    )
}