export default function SaveFolder({save2}) {
    console.log('heloooo')
    return (
        <div className="div9">
            <input type="text" name="" id="" placeholder={'Name of folder'} className="folderInp"/>
            <button className="btn2"
                    onClick={save2}>Save picture2
            </button>
        </div>
    )
}