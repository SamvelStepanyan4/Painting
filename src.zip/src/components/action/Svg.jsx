export default function Svg({update,color}) {
    return (
        <button className="btn1" onClick={() => {
            update(color)
        }}>
            <img src={process.env.PUBLIC_URL + '/img.svg'} alt=""/>
        </button>
    )
}