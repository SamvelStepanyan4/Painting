export default function Folder({folderFunc}) {
    return (
        <button className="btn1" onClick={() => {
            folderFunc()
        }}>
            <img src={process.env.PUBLIC_URL + '/folder.svg'} alt=""/>
        </button>
    )
}