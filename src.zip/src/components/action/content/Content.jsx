import ContentCreate from "./ContentCreate";

export default function Content({column, arrayContent, setArrayContent, color, brush, eraser, checkbox}) {
    return (
        <div className="main" style={{
            gridTemplateColumns: `repeat(${column} , 1fr)`
        }}>
            {arrayContent.map((value, index, array) => {
                return (<ContentCreate
                    setArrayContent={setArrayContent}
                    color={color}
                    key={index}
                    index={index}
                    value={value}
                    array={array}
                    brush={brush}
                    eraser={eraser}
                    checkbox={checkbox}
                />)
            })}
        </div>
    )
}