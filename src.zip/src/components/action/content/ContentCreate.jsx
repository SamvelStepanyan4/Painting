import {useEffect} from "react";

export default function ContentCreate({setArrayContent, color, value, index, array, brush, eraser, checkbox}) {


    let content = document.querySelector('.content')

    function colorChange() {
        if (brush) {
            console.log(brush)
            array[index] = {
                r: color.r,
                g: color.g,
                b: color.b
            }
            setArrayContent([...array])
        }
        if (eraser) {
            console.log(eraser)
            array[index] = {
                r: 255,
                g: 255,
                b: 255
            }
            setArrayContent([...array])
        }

    }

    return (
        <div className="content" style={{
            backgroundColor: `rgb(${array[index].r}, ${array[index].g}, ${array[index].b})`,
            border: checkbox === true ? 'none' : '1px solid'
        }}
             onClick={
                 () => {
                     colorChange()
                 }
             }>
        </div>
    )
}