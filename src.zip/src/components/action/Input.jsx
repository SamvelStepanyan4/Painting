export default function Input({setColor,colorRender,color}) {
    function componentToHex(c) {
        var hex = c.toString(16);
        return hex.length == 1 ? "0" + hex : hex;
    }

    function rgbToHex(r, g, b) {
        return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
    }

    return (
        <input type="color" className="inp2" value={rgbToHex(color.r,color.g,color.b)}
               onChange={e => {
                   console.log(document.querySelector('.inp2'))
                 colorRender(document.querySelector('.inp2'))
               }}/>
    )
}