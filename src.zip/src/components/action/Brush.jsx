export default function Brush({change}) {
    return (
        <button className="btn1"
                onClick={() => {
                    change()
                }}
        >
            <img src={process.env.PUBLIC_URL + '/brush.svg'} alt=""/>
        </button>
    )
}