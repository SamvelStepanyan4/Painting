export default function Eraser({clean}) {
    return (
        <button className="btn1"
                onClick={() => {
                    clean()
                }}
        >
            <img src={process.env.PUBLIC_URL + '/eraser.svg'} alt=""/>
        </button>
    )
}