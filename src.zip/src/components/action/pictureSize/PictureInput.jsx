export default function PictureInput({setColumn, generate, column}) {
    let columnInput

    return (
        <div>
            <div>
                <input type="number" min='0' max='75' name="" className="column"/>
                <input type="number" min='0' max='75' name="" className="row"/>
            </div>
            <button
                onClick={() => {
                    columnInput = document.querySelector('.column')
                    generate(columnInput)
                    // generate()
                }}>
                Generate
            </button>
        </div>
    )
}