export default function PictureSize({draw}) {
    return (<button className="btn1"
                    onClick={() => {
                        draw()
                    }}
    >
        <img src={process.env.PUBLIC_URL + '/pic.svg'} alt=""/>
    </button>)
}